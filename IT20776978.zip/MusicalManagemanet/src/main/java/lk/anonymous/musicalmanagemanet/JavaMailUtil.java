/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lk.anonymous.musicalmanagemanet;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class JavaMailUtil extends OrderInstruments {

    public static void sendMail(String Recepient) throws Exception {
        System.out.println("Sending Confirmation Email ");

        Properties properties = new Properties();

        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");

        properties.put("mail.smtp.port", "587");

        String Myaccountemail = "anonymousgtrrtx@gmail.com"; // Please provide here the email address to send customers emails
        String password = "wholetthedogsout"; //Please provide your password for the above email 
        
        
        // You should guve access to less security apps on gmail to use the email feature

        Session session = Session.getInstance(properties, new Authenticator() {

            @Override

            protected PasswordAuthentication getPasswordAuthentication() {

                return new PasswordAuthentication(Myaccountemail, password);
            }

        });

        Message message = prepareMessage(session, Myaccountemail, Recepient);

        Transport.send(message);
        System.out.println("Confirmation Email Sent Successfully");

    }

    private static Message prepareMessage(Session session, String Myaccountemail, String Recepient) {
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(Myaccountemail));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(Recepient));
            message.setSubject("Your Order Details");
            message.setText("Your Order Has Been Successfully Received ");
            return message;
        } catch (Exception e) {

            Logger.getLogger(JavaMailUtil.class.getName()).log(Level.SEVERE, null, e);
        }
        return null;

    }

}
