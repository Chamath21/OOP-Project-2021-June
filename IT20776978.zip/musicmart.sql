-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 14, 2021 at 01:15 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `musicmart`
--

-- --------------------------------------------------------

--
-- Table structure for table `accessories`
--

CREATE TABLE `accessories` (
  `Customername` varchar(100) NOT NULL,
  `Customeraddress` varchar(100) NOT NULL,
  `Customernumber` int(10) NOT NULL,
  `Accessorydetails` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accessories`
--

INSERT INTO `accessories` (`Customername`, `Customeraddress`, `Customernumber`, `Accessorydetails`) VALUES
('WFWFW', 'FWFWFFW', 1234567890, 'WFWFWF'),
('gsgs', 'gsegsegsg', 1234567890, 'gsegseg'),
('wfawf', 'wafwafwa', 1234567890, 'wfwawaf'),
('Chamath', 'Kaluthara	', 987654321, 'New');

-- --------------------------------------------------------

--
-- Table structure for table `assigning employees for repairs`
--

CREATE TABLE `assigning employees for repairs` (
  `Customer Email` varchar(100) NOT NULL,
  `Employee Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assigning employees for repairs`
--

INSERT INTO `assigning employees for repairs` (`Customer Email`, `Employee Name`) VALUES
('', 'gesege'),
('', 'gesege'),
('', 'gesege'),
('wfwffa', 'wafwafwaf'),
('esgsegseg', 'eggsgg');

-- --------------------------------------------------------

--
-- Table structure for table `expeses table`
--

CREATE TABLE `expeses table` (
  `Date` varchar(500) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Expenses` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expeses table`
--

INSERT INTO `expeses table` (`Date`, `Description`, `Expenses`) VALUES
('gsege', 'gesgeg', 332),
('rgg', 'ergeg', 34333),
('afwafwaf', 'wwaf', 123.98);

-- --------------------------------------------------------

--
-- Table structure for table `income report`
--

CREATE TABLE `income report` (
  `Date` varchar(10) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Income` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `income report`
--

INSERT INTO `income report` (`Date`, `Description`, `Income`) VALUES
('vgsg', 'gsefse', 1234),
('yrh', 'drhrddhdr', 1234);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Username`, `Password`) VALUES
('MusicMart', '#werethebest!');

-- --------------------------------------------------------

--
-- Table structure for table `orderins`
--

CREATE TABLE `orderins` (
  `Instrument Type` varchar(50) NOT NULL,
  `Customer Name` varchar(100) NOT NULL,
  `Customer Address` varchar(100) NOT NULL,
  `Customer Contact` int(10) NOT NULL,
  `Customer Email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderins`
--

INSERT INTO `orderins` (`Instrument Type`, `Customer Name`, `Customer Address`, `Customer Contact`, `Customer Email`) VALUES
('Guitar', 'Lakshan', 'Kaluthara', 717997836, ''),
('Guitar', 'Lakshan', 'Klauthara	', 3764734, ''),
('wrwe', 'twe4te', 'efefef', 234242, ''),
('wrfwf', 'fwafwaf', 'wfwfwaf', 123, ''),
('wdwd', 'fwdwad', 'wfwfwdwad', 121313, ''),
('Guitar', 'Chamath', 'kaluathara', 987654321, 'ryrhdrdr'),
('Guitar', 'Anonymous', 'Kaluthara', 746789089, 'info@123'),
('Guitar', 'Lakshan', 'Kaluthara', 1234567890, 'lakshanviduranga@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `repairform`
--

CREATE TABLE `repairform` (
  `Customer Name` varchar(50) NOT NULL,
  `Contact Number` int(10) NOT NULL,
  `Customer Email` varchar(100) NOT NULL,
  `Customer Address` varchar(100) NOT NULL,
  `Instrument Type` varchar(100) NOT NULL,
  `Special Notes And Details` varchar(500) NOT NULL,
  `Repair Code` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `repairform`
--

INSERT INTO `repairform` (`Customer Name`, `Contact Number`, `Customer Email`, `Customer Address`, `Instrument Type`, `Special Notes And Details`, `Repair Code`) VALUES
('Chamath', 987654321, 'info', 'kaluthara', 'Guitar', 'nothing', 4),
('Chamath', 987654321, 'jffefegs', 'segseg', 'sesggsgseg', 'egesgsgsg', 5),
('Lakshan', 717992684, 'lakshanviduranga1999@gmail.com', 'Kaluthara', 'Guitar', 'Repair form', 6);

-- --------------------------------------------------------

--
-- Table structure for table `supplierdetails`
--

CREATE TABLE `supplierdetails` (
  `Suppliername` varchar(50) NOT NULL,
  `Suppliercode` int(6) NOT NULL,
  `Suppliernumber` int(10) NOT NULL,
  `Supplieraddress` varchar(500) NOT NULL,
  `Orderdetails` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplierdetails`
--

INSERT INTO `supplierdetails` (`Suppliername`, `Suppliercode`, `Suppliernumber`, `Supplieraddress`, `Orderdetails`) VALUES
('wfafw', 12344, 1234567890, 'wfwf', 'wfwfwaf'),
('wfafw', 1234434, 1234567890, 'wfwf', 'wfwfwaf'),
('wfwaf', 123345, 1234567890, 'eeaga', 'geaga'),
('wtrqrqr', 123456, 1234567890, 'efgeagea', 'gagagea'),
('wafwf', 454323, 987654321, 'gawag', 'wawagwag'),
('chamath', 123456, 987654321, 'egsegse', 'gsegsegsegeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `repairform`
--
ALTER TABLE `repairform`
  ADD PRIMARY KEY (`Repair Code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `repairform`
--
ALTER TABLE `repairform`
  MODIFY `Repair Code` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
